﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace KifejezesErtekelo
{
	public class NumberEvaluator
	{
		public int Evaluate(string input)
		{
			string num1 = "";
			string num2 = "";
			char op = ' ';

			foreach (char c in input)
			{
				if (num1 == "" || op == ' ')
				{
					try
					{
						int.Parse(c.ToString());
						num1 += c;
					}
					catch (Exception)
					{
						op = c;
					}
				}
				else
				{
					num2 += c;
				}
			}

			switch (op)
			{
				case '+':
					return int.Parse(num1) + int.Parse(num2);
				case '*':
					return int.Parse(num1) * int.Parse(num2);
				case '/':
					return int.Parse(num1) / int.Parse(num2);
				case '-':
					return int.Parse(num1) - int.Parse(num2);
				default:
					throw new Exception();
			}
		}
	}
}