using NUnit.Framework;
using KifejezesErtekelo;

namespace KifejezesErtekelo.Tests
{
	public class NumberEvaluatorTests
	{
		NumberEvaluator evaluator;

		[OneTimeSetUp]
		public void Setup()
		{
			evaluator = new NumberEvaluator();
		}

		[Test]
		public void SimpleExpression()
		{
			double x = evaluator.Evaluate("2+6");
			Assert.That(x, Is.EqualTo(8));
		}

		[Test]
		public void WrongExpressionShouldntWork()
		{
			try
			{
				evaluator.Evaluate("2 6 +");
				Assert.Fail();
			}
			catch (Exception)
			{
				Assert.Pass();
			}
		}
	}
}